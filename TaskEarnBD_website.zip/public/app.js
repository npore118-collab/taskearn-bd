const $=s=>document.querySelector(s);
function openModal(type){
  $("#modal").classList.remove("hidden");
  $("#auth").innerHTML=type==="login"?`
  <h2>লগইন</h2><input id="email" placeholder="Email"><input id="password" type="password" placeholder="Password">
  <button onclick="login()">লগইন</button><p>নতুন? <a onclick="openModal('register')">সাইন আপ</a></p>`:
  `<h2>সাইন আপ</h2><input id="name" placeholder="নাম"><input id="email" placeholder="Email"><input id="password" type="password" placeholder="Password (6+)">
  <button onclick="register()">অ্যাকাউন্ট তৈরি করুন</button><p>আগে account আছে? <a onclick="openModal('login')">লগইন</a></p>`;
}
function closeModal(){$("#modal").classList.add("hidden")}
async function api(url,opt={}){const r=await fetch(url,{headers:{"Content-Type":"application/json"},...opt});const d=await r.json();if(!r.ok)throw Error(d.error||"Error");return d}
async function register(){try{const d=await api("/api/register",{method:"POST",body:JSON.stringify({name:$("#name").value,email:$("#email").value,password:$("#password").value})});location.href="/dashboard.html"}catch(e){alert(e.message)}}
async function login(){try{await api("/api/login",{method:"POST",body:JSON.stringify({email:$("#email").value,password:$("#password").value})});location.href="/dashboard.html"}catch(e){alert(e.message)}}

const express = require("express");
const session = require("express-session");
const Database = require("better-sqlite3");
const path = require("path");
require("dotenv").config();

const app = express();
const db = new Database("taskearn.db");
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({
  secret: process.env.SESSION_SECRET || "dev-only-change-me",
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true, sameSite:"lax", secure:false}
}));
app.use(express.static(path.join(__dirname,"public")));

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT UNIQUE NOT NULL,
 password TEXT NOT NULL,
 referral TEXT UNIQUE NOT NULL,
 balance REAL DEFAULT 0,
 tier TEXT DEFAULT 'Free',
 is_admin INTEGER DEFAULT 0,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS tasks(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 description TEXT,
 reward REAL NOT NULL,
 url TEXT,
 active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS completions(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER,
 task_id INTEGER,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(user_id,task_id)
);
CREATE TABLE IF NOT EXISTS withdrawals(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER,
 amount REAL,
 method TEXT,
 account TEXT,
 status TEXT DEFAULT 'Pending',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS prizes(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 label TEXT,
 amount REAL,
 probability REAL
);
`);

const count = db.prepare("SELECT COUNT(*) c FROM prizes").get().c;
if (!count) {
  const add = db.prepare("INSERT INTO prizes(label,amount,probability) VALUES(?,?,?)");
  const seed = db.transaction(() => {
    add.run("৳100 Reward",100,1);
    add.run("৳50 Reward",50,4);
    add.run("৳20 Reward",20,10);
    add.run("৳10 Reward",10,20);
    add.run("Bonus Task",0,65);
  });
  seed();
}

function requireLogin(req,res,next){
  if(!req.session.userId) return res.status(401).json({error:"Login required"});
  next();
}
function requireAdmin(req,res,next){
  if(!req.session.userId) return res.status(401).json({error:"Login required"});
  const u = db.prepare("SELECT * FROM users WHERE id=?").get(req.session.userId);
  if(!u || !u.is_admin) return res.status(403).json({error:"Super Admin only"});
  req.user=u; next();
}
function publicUser(id){
  return db.prepare("SELECT id,name,email,referral,balance,tier,is_admin,created_at FROM users WHERE id=?").get(id);
}

app.post("/api/register",(req,res)=>{
  const {name,email,password} = req.body;
  if(!name || !email || !password || password.length<6) return res.status(400).json({error:"Name, valid email and 6+ character password required"});
  const referral = "TE"+Math.random().toString(36).slice(2,8).toUpperCase();
  try {
    const info=db.prepare("INSERT INTO users(name,email,password,referral) VALUES(?,?,?,?)")
      .run(name,email.toLowerCase(),password,referral);
    req.session.userId=info.lastInsertRowid;
    res.json({user:publicUser(info.lastInsertRowid)});
  } catch(e){ res.status(400).json({error:"Email already registered"}); }
});

app.post("/api/login",(req,res)=>{
  const u=db.prepare("SELECT * FROM users WHERE email=? AND password=?").get((req.body.email||"").toLowerCase(),req.body.password||"");
  if(!u) return res.status(401).json({error:"Invalid login"});
  req.session.userId=u.id; res.json({user:publicUser(u.id)});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>{
  if(!req.session.userId) return res.json({user:null});
  res.json({user:publicUser(req.session.userId)});
});

app.get("/api/tasks",requireLogin,(req,res)=>{
  const rows=db.prepare(`
    SELECT t.*, CASE WHEN c.id IS NULL THEN 0 ELSE 1 END completed
    FROM tasks t LEFT JOIN completions c ON c.task_id=t.id AND c.user_id=?
    WHERE t.active=1 ORDER BY t.id DESC`).all(req.session.userId);
  res.json({tasks:rows});
});
app.post("/api/tasks/:id/complete",requireLogin,(req,res)=>{
  const t=db.prepare("SELECT * FROM tasks WHERE id=? AND active=1").get(req.params.id);
  if(!t) return res.status(404).json({error:"Task not found"});
  try {
    const tx=db.transaction(()=>{
      db.prepare("INSERT INTO completions(user_id,task_id) VALUES(?,?)").run(req.session.userId,t.id);
      db.prepare("UPDATE users SET balance=balance+? WHERE id=?").run(t.reward,req.session.userId);
    });
    tx(); res.json({user:publicUser(req.session.userId),message:"Reward added"});
  } catch(e){ res.status(400).json({error:"Task already completed"}); }
});

app.post("/api/withdraw",requireLogin,(req,res)=>{
  const amount=Number(req.body.amount), method=req.body.method, account=req.body.account;
  if(!amount || amount<500 || !method || !account) return res.status(400).json({error:"Minimum withdrawal is ৳500"});
  const u=publicUser(req.session.userId);
  if(amount>u.balance) return res.status(400).json({error:"Insufficient balance"});
  const tx=db.transaction(()=>{
    db.prepare("UPDATE users SET balance=balance-? WHERE id=?").run(amount,u.id);
    db.prepare("INSERT INTO withdrawals(user_id,amount,method,account) VALUES(?,?,?,?)").run(u.id,amount,method,account);
  });
  tx(); res.json({message:"Withdrawal request submitted",user:publicUser(u.id)});
});

function spinPrize(){
  const rows=db.prepare("SELECT * FROM prizes").all();
  const total=rows.reduce((s,r)=>s+r.probability,0);
  let n=Math.random()*total;
  for(const r of rows){ n-=r.probability; if(n<=0) return r; }
  return rows[rows.length-1];
}
app.post("/api/spin",requireLogin,(req,res)=>{
  const u=publicUser(req.session.userId);
  const cost=10;
  if(u.balance<cost) return res.status(400).json({error:"Spin costs ৳10"});
  const p=spinPrize();
  const tx=db.transaction(()=>{
    db.prepare("UPDATE users SET balance=balance-?+? WHERE id=?").run(cost,p.amount,u.id);
  });
  tx();
  res.json({prize:p,user:publicUser(u.id)});
});

app.get("/api/admin/stats",requireAdmin,(req,res)=>{
  res.json({
    users:db.prepare("SELECT COUNT(*) c FROM users").get().c,
    activeTasks:db.prepare("SELECT COUNT(*) c FROM tasks WHERE active=1").get().c,
    pendingWithdrawals:db.prepare("SELECT COUNT(*) c FROM withdrawals WHERE status='Pending'").get().c,
    balance:db.prepare("SELECT COALESCE(SUM(balance),0) s FROM users").get().s
  });
});
app.get("/api/admin/users",requireAdmin,(req,res)=>{
  res.json({users:db.prepare("SELECT id,name,email,referral,balance,tier,is_admin,created_at FROM users ORDER BY id DESC").all()});
});
app.post("/api/admin/tasks",requireAdmin,(req,res)=>{
  const {title,description,reward,url}=req.body;
  if(!title || Number(reward)<0) return res.status(400).json({error:"Title and reward required"});
  const info=db.prepare("INSERT INTO tasks(title,description,reward,url) VALUES(?,?,?,?)").run(title,description||"",Number(reward),url||"");
  res.json({id:info.lastInsertRowid});
});
app.get("/api/admin/withdrawals",requireAdmin,(req,res)=>{
  res.json({withdrawals:db.prepare(`
    SELECT w.*,u.name,u.email FROM withdrawals w JOIN users u ON u.id=w.user_id
    ORDER BY w.id DESC`).all()});
});
app.post("/api/admin/withdrawals/:id/status",requireAdmin,(req,res)=>{
  const w=db.prepare("SELECT * FROM withdrawals WHERE id=?").get(req.params.id);
  if(!w) return res.status(404).json({error:"Not found"});
  const status=req.body.status;
  if(!["Approved","Rejected"].includes(status)) return res.status(400).json({error:"Invalid status"});
  const tx=db.transaction(()=>{
    if(status==="Rejected" && w.status==="Pending")
      db.prepare("UPDATE users SET balance=balance+? WHERE id=?").run(w.amount,w.user_id);
    db.prepare("UPDATE withdrawals SET status=? WHERE id=?").run(status,w.id);
  });
  tx(); res.json({ok:true});
});

// Create the first Super Admin from environment on startup, if absent.
if(process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD){
  const existing=db.prepare("SELECT id FROM users WHERE email=?").get(process.env.ADMIN_EMAIL.toLowerCase());
  if(!existing){
    db.prepare("INSERT INTO users(name,email,password,referral,tier,is_admin) VALUES(?,?,?,?,?,1)")
      .run("Owner",process.env.ADMIN_EMAIL.toLowerCase(),process.env.ADMIN_PASSWORD,"OWNER","Super Admin");
  } else {
    db.prepare("UPDATE users SET is_admin=1,tier='Super Admin' WHERE email=?").run(process.env.ADMIN_EMAIL.toLowerCase());
  }
}

app.listen(PORT,()=>console.log(`TaskEarn BD running on http://localhost:${PORT}`));
